/*
 * Example plugin template
 */

jsPsych.plugins["active-production"] = (function() {

  var plugin = {};

  plugin.info = {
    name: "active-production",
    parameters: {
      image: {
        type: jsPsych.plugins.parameterType.IMAGE, // BOOL, STRING, INT, FLOAT, FUNCTION, KEYCODE, SELECT, HTML_STRING, IMAGE, AUDIO, VIDEO, OBJECT, COMPLEX
        default: undefined
      },
      sound: {
        type: jsPsych.plugins.parameterType.AUDIO,
        default: undefined
      }
    }
  }

  plugin.trial = function(display_element, trial) {
	console.log("hello")
	var face_name_procedure = {
    timeline: [
        {
            type: 'html-keyboard-response',
            stimulus: '+',
            choices: jsPsych.NO_KEYS,
            trial_duration: 500
        },
        {
            type: 'image-keyboard-response',
            stimulus: jsPsych.timelineVariable('img'),
            choices: jsPsych.NO_KEYS,
            trial_duration: 2500
        },
		{
            type: 'audio-keyboard-response',
            stimulus: jsPsych.timelineVariable('img'),
            choices: jsPsych.NO_KEYS,
            trial_duration: 500
        }
    ],
    timeline_variables: [
        { img: 'monster.jpg' },
        { sound: 'person-2.jpg' },
        { face: 'person-3.jpg' },
        { face: 'person-4.jpg' }
    ]
}
    // data saving
    var trial_data = {
      response_time: '12'
    };

    // end trial
    jsPsych.finishTrial(trial_data);
  };

  return plugin;
})();
